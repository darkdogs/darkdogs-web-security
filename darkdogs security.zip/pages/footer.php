      <footer>
        <div class="row">
          <div class="col-lg-12">
            <p>Protected by <strong><a href="darkdogs.org" target="_blank">DARKDOGS.org</a></strong></p>
          </div>
        </div>
      </footer>
    
    </div>
	
  </body>
</html>