<?php
include "../config.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>DARKDOGS SECURITY</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" href="../assets/img/favicon.png">
    <meta charset="utf-8">
    <META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css" media="screen">
    <script src="../assets/js/jquery-3.3.1.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
  </head>
  <body>

    <div class="container">