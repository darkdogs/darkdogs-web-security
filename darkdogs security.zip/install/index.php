<?php
include "core.php";
head();
?>
                            <center>
                                <p><?php
echo lang_key("choose_language");
?>: </p>
                                <select name="language" class="form-control" size="4"  onChange="top.location.href=this.options[this.selectedIndex].value;" required autofocus>
                                  <option value="?lang=en" <?php
if ($curr_lang == "en") {
    echo 'selected';
}
?>>English</option>
                                  
                                </select>
                                
                                </center>
                                
                                <br />
                                
                                <form action="database" method="post">
                                <div class="form-group">
                                   
                                    <div class="radio">
                                        <p>
                                            <input type="radio" name="type" value="Client" checked>
                                            <strong><?php
echo lang_key("lite_installation");
?></strong> - <?php
echo lang_key("lite_description");
?>
                                        </p>
                                    </div>
                                </div>
                                
                                <br />
                            <center>
                                
                                <input name="nextstep" type="submit" class="btn btn-primary" value="<?php
echo lang_key("continue");
?>" />
                                </form>
                            </center>
<?php
footer();
?>